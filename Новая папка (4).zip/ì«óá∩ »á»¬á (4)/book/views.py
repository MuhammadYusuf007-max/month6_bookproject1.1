from django.shortcuts import render

def books_list_view(request):
    return render(request, template_name='books.html')


