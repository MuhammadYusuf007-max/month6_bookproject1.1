from django.contrib import admin
from book.models import BookModel


@admin.register(BookModel)
class BookModeladmin(admin.ModelAdmin):
    list_display = ['author', 'title', 'pages']
    search_fields = ['tile']
    list_filter = ['created_at']
